import java.util.ArrayList;
import java.util.Random;

public class QuoteGenerator {
    public static void main(String[] args) {
        // Create a list of inspirational quotes
        ArrayList<String> quotes = new ArrayList<>();
        quotes.add("The only way to do great work is to love what you do. - Steve Jobs");
        quotes.add("Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill");
        quotes.add("In the middle of every difficulty lies opportunity. - Albert Einstein");
        quotes.add("The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt");
        quotes.add("Don't watch the clock; do what it does. Keep going. - Sam Levenson");

        // Create a Random object to generate random indices
        Random random = new Random();

        // Generate a random index to select a quote
        int randomIndex = random.nextInt(quotes.size());

        // Display the randomly selected quote
        String randomQuote = quotes.get(randomIndex);
        System.out.println("Random Inspirational Quote:");
        System.out.println(randomQuote);
    }
}
